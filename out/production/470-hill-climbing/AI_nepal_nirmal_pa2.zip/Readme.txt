run
javac *.java

and then
java Main




The starting jump sequence is the algorithm follows the probability function

delta e  = next - current;

exp = exp(e/t),
and t is decreased everytime by 0.02


This then gets us better result than hill climbing.
