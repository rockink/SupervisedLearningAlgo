import java.util.List;

/**
 * Created by rockink on 4/19/17.
 */
public class Result {

    int numOfGoalStatesReached;
    List<Integer> successMoves;
    List<Integer> stuckMoves;


}
