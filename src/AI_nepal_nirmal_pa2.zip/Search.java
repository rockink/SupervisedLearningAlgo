/**
 * Created by rockink on 4/19/17.
 */
abstract public class Search {


}
