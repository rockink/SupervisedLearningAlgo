run
javac *.java

and then
java Main




The starting jump sequence is the algorithm follows the probability function

delta e  = next - current;

exp = exp(e/t),
and t is decreased everytime by 0.02

if (t is less than 0.02) and heuristic is not 0, hill climbing is done.
else it is returned to goal.

This then gets us better result than hill climbing.
